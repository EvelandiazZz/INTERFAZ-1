package Main;

import yFrame.DashBoard;


public class Main {
    
    public static void main(String[] args){
        
        DashBoard newlogin = new DashBoard();
        newlogin.setVisible(true);

    }
}
